#!/bin/bash
echo "Starting SQL Anywhere Sync Tool..."
echo
./SyncTool
read -p "Press Enter to exit..."
